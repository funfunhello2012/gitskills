'''
测试代码
新知识、数据分析、验证
'''
{"cmts":
	 [
		 {'approve': 0,
		  'approved': False,
		  'assistAwardInfo':
			  {'avatar': '', 'celebrityId': 0, 'celebrityName': '', 'rank': 0, 'title': ''},
		  'authInfo': '',
		  'avatarurl': 'https://img.meituan.net/avatar/50bed765f0c5320653cfe51223da236f188690.jpg',
		  'cityName': '盱眙',
		  'content': '校园暴力真的是一个值得深思的问题，因为它到现在依然没有得到解决。\n原著党表示，改编还是不错的，毕竟要过审，有些敏感话题还是要回避的，但是已经挺好了，算是回忆了下青春~',
		  'filmView': False,
		  'gender': 2,
		  'id': 1039672128, 'isMajor': False,
		  'juryLevel': 0, 'majorType': 0,
		  'movieId': 1217236,
		  'nick': '糖小喵CC',
		  'nickName': '点点',
		  'oppose': 0, 'pro': False, 'reply': 0, 'score': 4.5,
		  'spoiler': 0, 'startTime': '2018-09-21 21:09:29',
		  'supportComment': True, 'supportLike': True,
		  'sureViewed': 0,
		  'tagList':
			  {'fixed': [{'id': 1, 'name': '好评'}, {'id': 4, 'name': '购票'}]},
		  'time': '2018-09-21 21:09', 'userId': 50828768,
		  'userLevel': 3,
		  'videoDuration': 0, 'vipInfo': '',
		  'vipType': 0}
		 ],
	"total":39501
}
# page_num = 20/5
# print(page_num)
# def sex_distribution(gender = [1,2,1,2,1,0,2,0,0,0,0,1]):
# 	gender_list = list(set(gender))
#
# 	print(gender_list)
# 	list_num = []
# 	list_num.append(gender.count(0))
# 	list_num.append(gender.count(1))
# 	list_num.append(gender.count(2))
# 	print(list_num)
#
# sex_distribution()
# city_name = []
# city_num = []
# dic = {'a': 31, 'bc': 5, 'c': 3, 'asd': 4, 'aa': 74, 'd': 0}
# sort_dict = sorted(dic.items(), key=lambda d: d[1], reverse=True)
# for i in range(len(sort_dict)):
# 	city_name.append(sort_dict[i][0])
# 	city_num.append(sort_dict[i][1])
# print(city_name)
# print(city_num)

str01 = 'hhhsb'
str01 = str01.replace("h","a")
print(str01)